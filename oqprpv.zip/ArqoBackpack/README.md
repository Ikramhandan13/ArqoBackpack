<div align="center">

# 🎒 ArqoBackpack
**Premium Lightweight Backpack Solution for Modern Servers**

[![Version](https://img.shields.io/badge/version-1.0.0-blue.svg)](https://github.com/Arqonara-Hosting)
[![Minecraft](https://img.shields.io/badge/minecraft-1.20.1--1.21.1-green.svg)](https://papermc.io)
[![Java](https://img.shields.io/badge/java-21%2B-orange.svg)](https://www.oracle.com/java/)

</div>

---

## 🌟 Overview
**ArqoBackpack** adalah plugin penyimpanan portable yang efisien, mendukung Paper, Purpur, dan Folia. Dibuat untuk performa tinggi dengan sistem database asinkron.

## 🚀 Features
* **Folia-Ready**: Thread-safe operations.
* **Smart Downgrade Protection**: Item tidak akan hilang jika kapasitas tas berkurang.
* **Anti-Dupe**: Sesi tas dikunci per pemain.
* **Sneak Trigger**: Buka tas tanpa command (5x sneak).

## 🔑 Permissions
* `arqobackpack.use`: Akses dasar.
* `arqobackpack.size.<9|18|27|36|45|54>`: Menentukan ukuran tas.

## 🏗️ Build
```bash
mvn clean package

🤝 Contributing
Contributions are welcome! Please follow ini:
​Fork the repository
​Create a feature branch
​Commit your changes
​Push to the branch
​Open a Pull Request
​🌟 Credits
Developed by: Arqonara Hosting: Arqonara Hosting
Author: Dzakiri - Arqonara

