package com.arqonara.backpack.listener;

import com.arqonara.backpack.ArqoBackpack;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerToggleSneakEvent;

import java.util.UUID;

public class PlayerListener implements Listener {
    private final ArqoBackpack plugin;

    public PlayerListener(ArqoBackpack plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onSneak(PlayerToggleSneakEvent e) {
        if (e.isSneaking()) plugin.getManager().handleSneak(e.getPlayer());
    }

    @EventHandler
    public void onClose(InventoryCloseEvent e) {
        String title = e.getView().getTitle();
        if (title.contains(plugin.getConfig().getString("backpack.title"))) {
            UUID ownerId;
            if (title.contains(": ")) {
                String name = title.split(": ")[1];
                Player p = Bukkit.getPlayer(name);
                ownerId = (p != null) ? p.getUniqueId() : null;
            } else {
                ownerId = e.getPlayer().getUniqueId();
            }
            if (ownerId != null) plugin.getManager().closeSession(ownerId, e.getInventory());
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        plugin.getManager().getOpenSessions().remove(e.getPlayer().getUniqueId());
    }
}
