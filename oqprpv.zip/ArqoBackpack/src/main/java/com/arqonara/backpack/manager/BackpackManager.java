package com.arqonara.backpack.manager;

import com.arqonara.backpack.ArqoBackpack;
import org.bukkit.Bukkit;
import org.bukkit.Particle;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class BackpackManager {
    private final ArqoBackpack plugin;
    private final Map<UUID, Long> cooldowns = new HashMap<>();
    private final Map<UUID, List<Long>> sneakData = new HashMap<>();
    private final Set<UUID> openSessions = Collections.newSetFromMap(new ConcurrentHashMap<>());

    public BackpackManager(ArqoBackpack plugin) {
        this.plugin = plugin;
    }

    public int getSize(Player player) {
        for (int i = 54; i >= 18; i -= 9) {
            if (player.hasPermission("arqobackpack.size." + i)) return i;
        }
        return plugin.getConfig().getInt("backpack.default-size", 9);
    }

    public void open(Player viewer, Player owner) {
        if (openSessions.contains(owner.getUniqueId())) {
            viewer.sendMessage(plugin.getMessage("already-open"));
            return;
        }
        plugin.getDb().load(owner.getUniqueId()).thenAccept(data -> {
            Bukkit.getScheduler().runTask(plugin, () -> {
                int size = getSize(owner);
                String title = viewer.equals(owner) ? plugin.getConfig().getString("backpack.title") : plugin.getConfig().getString("backpack.admin-title").replace("%player%", owner.getName());
                Inventory inv = Bukkit.createInventory(null, size, title);
                ItemStack[] saved = plugin.getDb().deserialize(data[0]);
                ItemStack[] overflowSaved = plugin.getDb().deserialize(data[1]);
                List<ItemStack> all = new ArrayList<>(Arrays.asList(saved));
                all.addAll(Arrays.asList(overflowSaved));
                ItemStack[] display = new ItemStack[size];
                for (int i = 0; i < size && i < all.size(); i++) display[i] = all.get(i);
                inv.setContents(display);
                openSessions.add(owner.getUniqueId());
                viewer.openInventory(inv);
                playEffects(viewer);
            });
        });
    }

    private void playEffects(Player p) {
        if (!plugin.getConfig().getBoolean("animation.enabled")) return;
        p.playSound(p.getLocation(), org.bukkit.Sound.valueOf(plugin.getConfig().getString("animation.sound")), 1f, 1f);
        p.sendActionBar(plugin.getConfig().getString("animation.actionbar"));
        if (plugin.getConfig().getBoolean("animation.particles.enabled")) {
            p.getWorld().spawnParticle(Particle.valueOf(plugin.getConfig().getString("animation.particles.type")), p.getLocation().add(0, 1, 0), plugin.getConfig().getInt("animation.particles.count"), 0.5, 0.5, 0.5, 0.1);
        }
    }

    public void handleSneak(Player p) {
        long now = System.currentTimeMillis();
        UUID id = p.getUniqueId();
        if (cooldowns.getOrDefault(id, 0L) > now) return;
        List<Long> sneaks = sneakData.computeIfAbsent(id, k -> new ArrayList<>());
        sneaks.add(now);
        sneaks.removeIf(t -> now - t > plugin.getConfig().getLong("open-trigger.window-ms"));
        if (sneaks.size() >= plugin.getConfig().getInt("open-trigger.sneaks-required")) {
            sneaks.clear();
            cooldowns.put(id, now + plugin.getConfig().getLong("open-trigger.cooldown-ms"));
            open(p, p);
        }
    }

    public void closeSession(UUID ownerId, Inventory inv) {
        plugin.getDb().load(ownerId).thenAccept(data -> {
            ItemStack[] current = inv.getContents();
            ItemStack[] oldOverflow = plugin.getDb().deserialize(data[1]);
            List<ItemStack> fullList = new ArrayList<>(Arrays.asList(current));
            fullList.addAll(Arrays.asList(oldOverflow));
            fullList.removeIf(Objects::isNull);
            int size = inv.getSize();
            ItemStack[] toSave = new ItemStack[size];
            List<ItemStack> newOverflow = new ArrayList<>();
            for (int i = 0; i < fullList.size(); i++) {
                if (i < size) toSave[i] = fullList.get(i);
                else newOverflow.add(fullList.get(i));
            }
            plugin.getDb().save(ownerId, plugin.getDb().serialize(toSave), plugin.getDb().serialize(newOverflow.toArray(new ItemStack[0])));
            openSessions.remove(ownerId);
        });
    }

    public Set<UUID> getOpenSessions() { return openSessions; }
}
