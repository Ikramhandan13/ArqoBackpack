package com.arqonara.backpack.storage;

import com.arqonara.backpack.ArqoBackpack;
import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import java.util.Base64;
import org.bukkit.inventory.ItemStack;
import org.bukkit.util.io.BukkitObjectInputStream;
import org.bukkit.util.io.BukkitObjectOutputStream;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;

public class Database {
    private final ArqoBackpack plugin;
    private HikariDataSource ds;

    public Database(ArqoBackpack plugin) {
        this.plugin = plugin;
        init();
    }

    private void init() {
        HikariConfig config = new HikariConfig();
        String type = plugin.getConfig().getString("storage.type", "sqlite");
        if (type.equalsIgnoreCase("mysql")) {
            config.setJdbcUrl("jdbc:mysql://" + plugin.getConfig().getString("storage.mysql.host") + ":" + plugin.getConfig().getInt("storage.mysql.port") + "/" + plugin.getConfig().getString("storage.mysql.database"));
            config.setUsername(plugin.getConfig().getString("storage.mysql.username"));
            config.setPassword(plugin.getConfig().getString("storage.mysql.password"));
            config.addDataSourceProperty("useSSL", plugin.getConfig().getBoolean("storage.mysql.useSSL"));
            config.setMaximumPoolSize(plugin.getConfig().getInt("storage.mysql.poolSize", 10));
        } else {
            config.setJdbcUrl("jdbc:sqlite:" + plugin.getDataFolder() + "/" + plugin.getConfig().getString("storage.sqlite.file"));
            config.setMaximumPoolSize(1); // SQLite works best with a single connection
        }
        ds = new HikariDataSource(config);
        try (Connection c = ds.getConnection(); PreparedStatement s = c.prepareStatement("CREATE TABLE IF NOT EXISTS backpacks (uuid VARCHAR(36) PRIMARY KEY, content TEXT, overflow TEXT)")) {
            s.execute();
        } catch (SQLException e) {
            plugin.getLogger().log(Level.SEVERE, "Could not create database table", e);
        }
    }

    public CompletableFuture<String[]> load(UUID uuid) {
        return CompletableFuture.supplyAsync(() -> {
            try (Connection c = ds.getConnection(); PreparedStatement s = c.prepareStatement("SELECT content, overflow FROM backpacks WHERE uuid = ?")) {
                s.setString(1, uuid.toString());
                ResultSet rs = s.executeQuery();
                if (rs.next()) return new String[]{rs.getString("content"), rs.getString("overflow")};
            } catch (SQLException e) {
                plugin.getLogger().log(Level.SEVERE, "Could not load backpack for " + uuid, e);
            }
            return new String[]{"", ""};
        });
    }

    public void save(UUID uuid, String content, String overflow) {
        CompletableFuture.runAsync(() -> {
            try (Connection c = ds.getConnection(); PreparedStatement s = c.prepareStatement("REPLACE INTO backpacks (uuid, content, overflow) VALUES (?, ?, ?)")) {
                s.setString(1, uuid.toString());
                s.setString(2, content);
                s.setString(3, overflow);
                s.executeUpdate();
            } catch (SQLException e) {
                plugin.getLogger().log(Level.SEVERE, "Could not save backpack for " + uuid, e);
            }
        });
    }

    public String serialize(ItemStack[] items) {
        try (ByteArrayOutputStream os = new ByteArrayOutputStream();
             BukkitObjectOutputStream data = new BukkitObjectOutputStream(os)) {
            data.writeInt(items.length);
            for (ItemStack item : items) data.writeObject(item);
            return Base64.getEncoder().encodeToString(os.toByteArray());
        } catch (Exception e) {
            plugin.getLogger().log(Level.SEVERE, "Could not serialize item stacks", e);
            return "";
        }
    }

    public ItemStack[] deserialize(String base64) {
        if (base64 == null || base64.isEmpty()) return new ItemStack[0];
        try (ByteArrayInputStream is = new ByteArrayInputStream(Base64.getDecoder().decode(base64));
             BukkitObjectInputStream data = new BukkitObjectInputStream(is)) {
            ItemStack[] items = new ItemStack[data.readInt()];
            for (int i = 0; i < items.length; i++) items[i] = (ItemStack) data.readObject();
            return items;
        } catch (Exception e) {
            plugin.getLogger().log(Level.SEVERE, "Could not deserialize item stacks", e);
            return new ItemStack[0];
        }
    }

    public void close() {
        if (ds != null) ds.close();
    }
}
