package com.arqonara.backpack.command;

import com.arqonara.backpack.ArqoBackpack;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class BackpackCommand implements CommandExecutor {
    private final ArqoBackpack plugin;

    public BackpackCommand(ArqoBackpack plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage(plugin.getMessage("player-only"));
            return true;
        }
        if (args.length == 1) {
            if (args[0].equalsIgnoreCase("reload")) {
                if (!p.hasPermission("arqobackpack.reload")) {
                    p.sendMessage(plugin.getMessage("no-permission"));
                    return true;
                }
                plugin.reloadConfig();
                p.sendMessage(plugin.getMessage("reload-success"));
                return true;
            }
            if (!p.hasPermission("arqobackpack.open.others")) {
                p.sendMessage(plugin.getMessage("no-permission"));
                return true;
            }
            Player target = Bukkit.getPlayer(args[0]);
            if (target == null) {
                p.sendMessage(plugin.getMessage("not-found"));
                return true;
            }
            plugin.getManager().open(p, target);
            return true;
        }
        if (!p.hasPermission("arqobackpack.use")) {
            p.sendMessage(plugin.getMessage("no-permission"));
            return true;
        }
        plugin.getManager().open(p, p);
        return true;
    }
}
