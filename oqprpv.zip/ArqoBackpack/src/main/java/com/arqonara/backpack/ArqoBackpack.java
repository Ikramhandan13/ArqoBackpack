package com.arqonara.backpack;

import com.arqonara.backpack.command.BackpackCommand;
import com.arqonara.backpack.listener.PlayerListener;
import com.arqonara.backpack.manager.BackpackManager;
import com.arqonara.backpack.storage.Database;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;

public class ArqoBackpack extends JavaPlugin {
    private Database db;
    private BackpackManager manager;
    private FileConfiguration messages;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        loadMessages();
        db = new Database(this);
        manager = new BackpackManager(this);
        getCommand("backpack").setExecutor(new BackpackCommand(this));
        getServer().getPluginManager().registerEvents(new PlayerListener(this), this);
        getLogger().info("ArqoBackpack by Dzakiri enabled!");
    }

    @Override
    public void onDisable() {
        if (db != null) db.close();
    }

    @Override
    public void reloadConfig() {
        super.reloadConfig();
        loadMessages();
    }

    private void loadMessages() {
        File file = new File(getDataFolder(), "messages.yml");
        if (!file.exists()) saveResource("messages.yml", false);
        messages = YamlConfiguration.loadConfiguration(file);
    }

    public String getMessage(String path) {
        return messages.getString("prefix", "") + messages.getString(path, path).replace("&", "§");
    }

    public Database getDb() { return db; }
    public BackpackManager getManager() { return manager; }
}
